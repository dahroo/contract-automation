from routes.worker_queue import worker_queue_bp
from routes.mail import mail_bp
from routes.auth import auth_bp
