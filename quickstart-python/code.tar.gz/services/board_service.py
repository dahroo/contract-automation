import requests

def create_monday_board(board_name, board_kind, api_key):
    url = "https://api.monday.com/v2/"
    headers = {"Authorization": api_key}
    query = '''
    mutation ($boardName: String!, $boardKind: BoardKind!) {
      create_board (board_name: $boardName, board_kind: $boardKind) {
        id
      }
    }
    '''
    variables = {
        "boardName": board_name,
        "boardKind": board_kind
    }
    response = requests.post(url, json={'query': query, 'variables': variables}, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception("Failed to create board: " + response.text)