import os

SAM_GOV_API_KEY = os.getenv('SAM_GOV_API_KEY')
MONDAY_API_KEY = os.getenv('MONDAY_API_KEY')

from services.board_service import create_monday_board

from flask import Flask, jsonify
from flask import request
from werkzeug.exceptions import HTTPException

from errors import handle_monday_code_api_error, handle_general_http_exception, \
    MondayCodeAPIError, handle_base_error, BaseError
from routes import worker_queue_bp, mail_bp, auth_bp

app = Flask(__name__)
app.register_blueprint(worker_queue_bp)
app.register_blueprint(mail_bp, url_prefix="/mail")
app.register_blueprint(auth_bp, url_prefix="/auth")

app.register_error_handler(HTTPException, handle_general_http_exception)
app.register_error_handler(BaseError, handle_base_error)
app.register_error_handler(MondayCodeAPIError, handle_monday_code_api_error)


@app.route("/", methods=["POST"])
def create_board():
    board_name = request.json.get("board_name", "Default Board Name")
    board_kind = request.json.get("board_kind", "private")  # Ensure 'public', 'private', or 'share' is provided
    try:
        result = create_monday_board(board_name, board_kind, MONDAY_API_KEY)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
