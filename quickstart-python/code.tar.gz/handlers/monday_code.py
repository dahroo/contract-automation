import monday_code

# Defining the host is optional and defaults to http://localhost:59999
# See configuration.py for a list of all supported configuration parameters.
mcode_configuration = monday_code.Configuration()
